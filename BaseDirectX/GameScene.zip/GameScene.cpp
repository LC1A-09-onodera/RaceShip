#include"GameScene.h"
#include "BaseDirectX.h"
#include "../WindowsAPI/WinAPI.h"
#include "Input.h"
#include "../Sound/Sound.h"
#include "viewport.h"
#include "../Particle/Particle3D.h"
#include "../imgui/ImguiControl.h"
#include "../Player/Player.h"
#include "../Enemy.h"
#include "vec3.h"

GameScene::GameScene()
{
	SceneNum = TITLE;
}

void GameScene::SceneManageUpdateAndDraw()
{
	Input::Update();
	WindowsAPI::CheckMsg();
	switch (SceneNum)
	{
	case TITLE:
		TitleUpdate();
		TitleDraw();
		break;
	case GAME:
		GameUpdate();
		GameDraw();
		break;
	case END:
		EndUpdate();
		EndDraw();
		break;
	default:
		break;
	}

}

void GameScene::Init()
{
	BaseDirectX::Set();
	//�T�E���h
	Sound::CreateVoice();
	//SRV�̃A�h���X�m��
	BaseDirectX::GetAdress();
	//�J����������
	Camera::Init();
	//Imgui�̏�����
	Imgui::Init();
	// 3D�p�[�e�B�N���ÓI������
	if (!ParticleManager::StaticInitialize(BaseDirectX::dev.Get(), window_width, window_height, Camera::eye, Camera::target, Camera::up))
	{
		assert(0);
	}
	particleMan = particleMan->Create(L"Resource/Img/kiiro.png");
	particleMan->StartParticle();
	particleMan2 = particleMan2->Create(L"Resource/Img/effect1.png");
	particleMan2->StartParticle();
	sentou.CreateModel("sentoki");
	sentou.Init(1);
	sentou.rotation.y = 180;
	sentou.position.m128_f32[1] = -10;

	//�o��l��
	Enemy::Init();
	Player::Init();

	//�C���v�b�g������
	Input::KeySet(WindowsAPI::w, WindowsAPI::hwnd);

	Camera::eyeMoveCircleHorizonal({
	sentou.position.m128_f32[0],
	sentou.position.m128_f32[1],
	sentou.position.m128_f32[2]
		});

}

void GameScene::GameUpdate()
{
	if (Input::KeyTrigger(DIK_R))
	{
		SceneNum = END;
	}
}

void GameScene::TitleUpdate()
{
	Camera::cameraAngleHorizonal = 0.0f;
	Camera::cameraAngleVertical = 0.0f;

	if (Input::Key(DIK_RIGHT))
	{
		ParticleManager::CameraMoveEyeVector({ 1.0f, 0.0f, 0.0f });
	}
	if (Input::Key(DIK_LEFT))
	{
		ParticleManager::CameraMoveEyeVector({ -1.0f,0.0f, 0.0f });
	}
	if (Input::Key(DIK_UP))
	{
		ParticleManager::CameraMoveEyeVector({ 0.0f, 1.0f, 0.0f });
	}
	if (Input::Key(DIK_DOWN))
	{
		ParticleManager::CameraMoveEyeVector({ 0.0f,-1.0f, 0.0f });
	}
	if (Input::KeyTrigger(DIK_SPACE))
	{
		particleMan->StartParticle();
	}

	//if (Input::Key(DIK_RIGHT) || Input::Key(DIK_LEFT) || Input::Key(DIK_UP) || Input::Key(DIK_DOWN)) {

	//	if (Input::Key(DIK_RIGHT)) {
	//		Camera::cameraAngleHorizonal += XMConvertToRadians(3.0f);
	//		Camera::eyeMoveCircleHorizonal({
	//			sentou.position.m128_f32[0],
	//			sentou.position.m128_f32[1],
	//			sentou.position.m128_f32[2]
	//			});
	//	}
	//	if (Input::Key(DIK_LEFT)) {
	//		Camera::cameraAngleHorizonal -= XMConvertToRadians(3.0f);
	//		Camera::eyeMoveCircleHorizonal({
	//			sentou.position.m128_f32[0],
	//			sentou.position.m128_f32[1],
	//			sentou.position.m128_f32[2]
	//			});
	//	}
	//	if (Input::Key(DIK_UP)) {
	//		Camera::cameraAngleVertical += XMConvertToRadians(3.0f);

	//		Camera::eyeMoveCircleVertical({
	//			sentou.position.m128_f32[0],
	//			sentou.position.m128_f32[1],
	//			sentou.position.m128_f32[2]
	//			});
	//	}
	//	if (Input::Key(DIK_DOWN)) {
	//		Camera::cameraAngleVertical -= XMConvertToRadians(3.0f);

	//		Camera::eyeMoveCircleVertical({
	//			sentou.position.m128_f32[0],
	//			sentou.position.m128_f32[1],
	//			sentou.position.m128_f32[2]
	//			});
	//	}
	//}

	particleMan->Update(Camera::eye, Camera::target, Camera::up);
	particleMan2->Update(Camera::eye, Camera::target, Camera::up);
	sentou.Update();

	Enemy::Update();
	Player::Update();

	if (Input::KeyTrigger(DIK_R))
	{
 		SceneNum = GAME;
	}
}

void GameScene::EndUpdate()
{
	if (Input::KeyTrigger(DIK_R))
	{
		SceneNum = TITLE;
	}
}

void GameScene::GameDraw()
{
	BaseDirectX::UpdateFront();

	Imgui::DrawImGui();
	//�`��R�}���h�����܂�
	BaseDirectX::UpdateBack();
}

void GameScene::TitleDraw()
{
	BaseDirectX::UpdateFront();
	ParticleDraw(BaseDirectX::cmdList.Get(), particleMan);
	Draw3DObject(sentou);

	Enemy::Draw();
	Player::Draw();

	Imgui::DrawImGui();
	//�`��R�}���h�����܂�
	BaseDirectX::UpdateBack();
}

void GameScene::EndDraw()
{
	BaseDirectX::UpdateFront();

	Imgui::DrawImGui();
	//�`��R�}���h�����܂�
	BaseDirectX::UpdateBack();
}

void GameScene::ReStartSet()
{
}
