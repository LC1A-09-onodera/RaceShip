#pragma once
#include <math.h>
#include <DirectXMath.h>
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")


class Vec3 
{
public:
	float x;
	float y;
	float z;

	Vec3()
	{
		x = 0.0f;
		y = 0.0f;
		z = 0.0f;
	};
	Vec3(float x, float y, float z):
	x(x),y(y),z(z)
	{

	};

	float length() const
	{

	};

	Vec3 &nomalize()
	{
		Vec3 v;
		v.x = this->x / sqrtf(this->x * this->x + this->y * this->y + this->z * this->z);
		v.y = this->y / sqrtf(this->x * this->x + this->y * this->y + this->z * this->z);
		v.z = this->z / sqrtf(this->x * this->x + this->y * this->y + this->z * this->z);
		return v;
	}

	float dot(const Vec3 &other) const
	{
		return this->x * other.x + this->y * other.y + this->z * other.z;
	}

	Vec3 cross(const Vec3 &other) const
	{
		Vec3 v;
		v.x = this->y * other.z - this->z * other.y;
		v.y = this->z * other.x - this->x * other.z;
		v.z = this->x * other.y - this->y * other.x;
		return v;
	}

	Vec3 operator + (const Vec3 &other) const
	{
		Vec3 v;
		v.x = this->x + other.x;
		v.y = this->y + other.y;
		v.z = this->z + other.z;
		return v;
	}

	Vec3 operator - (const Vec3 &other) const
	{
		Vec3 v;
		v.x = this->x - other.x;
		v.y = this->y - other.y;
		v.z = this->z - other.z;
		return v;
	}

	Vec3 operator * (float other) const
	{
		this->x* other;
		this->y* other;
		this->z* other;
		return *this;
	}

	//+=�̃I�[�o�[���[�h
	Vec3 &operator += (const Vec3 &other)
	{
		this->x += other.x;
		this->y += other.y;
		this->z += other.z;
		return *this;
	}

	Vec3 &operator -= (const Vec3 &other)
	{
		this->x -= other.x;
		this->y -= other.y;
		this->z -= other.z;
		return *this;
	}

	Vec3 &operator *= (float other)
	{
		this->x *= other;
		this->y *= other;
		this->z *= other;
		return *this;
	}

	Vec3 &operator /= (float other)
	{
		this->x /= other;
		this->y /= other;
		this->z /= other;
		return *this;
	}

	static Vec3 lerp(const Vec3& strat, const Vec3& end, const float t) {
		return strat * (1.0f - t) + end * t;
	}
};